#!/usr/local/bin/python
# -*- coding: utf-8 -*-

from ety import cli

if __name__ == "__main__":
    cli()
